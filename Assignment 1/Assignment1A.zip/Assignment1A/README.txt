Programmen är skrivna i en texteditor (Sublime Text), 
komplerade med monodevelop på Mac (kommandot csc),
och provkörda i en terminal med kommandot mono.


Helge Stenström
