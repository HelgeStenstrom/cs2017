// Helge Stenström
// 2017-09-08
// Programmering med C#


namespace Assignment2
{
  /// <summary>
  /// This is the main entry of the program.
  /// </summary>
  /// <remarks>I have no use of this comment, since I have no tool to extract it.</remarks>
  /// 
 
  class MainProgram
  {
    static void Main(string[] args)
    {
      Startable menu = new Menu();
      menu.Start();
    }
  }

}