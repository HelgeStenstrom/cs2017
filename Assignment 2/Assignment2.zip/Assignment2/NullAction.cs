// Helge Stenström
// 2017-09-08
// Programmering med C#


namespace Assignment2 
{
  class NullAction : Startable {
    // A Null object which provides a method that does nothing.
    public void Start() {}
  }
}
