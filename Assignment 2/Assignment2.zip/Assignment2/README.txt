README.txt

Helge Stenström 2017-09-11


Inlämningsuppgift 2, VG-varianten.

Bortse från filen test.cs, den är ett försök att lära mig unit tests med C#, och fungerar inte ännu, mest för att alla intressanta metoder är privata.

