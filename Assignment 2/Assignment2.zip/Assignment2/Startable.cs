// Helge Stenström
// 2017-09-08
// Programmering med C#


namespace Assignment2
{
	interface Startable
  // All subprograms in used Menu.cs implements this interface.
	{
	   void Start();
	}
}
